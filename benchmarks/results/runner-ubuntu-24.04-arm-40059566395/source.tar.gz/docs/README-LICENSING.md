## Licensing

This project uses the **Kiyoshima Open** profile.

Controlling legal license expression: **`MIT OR Apache-2.0`**.

Kiyoshima Open is not a separate software license and does not modify the
standard license terms. `KIYOSHIMA.json` provides machine-readable licensing
metadata for tooling, CI, IDEs, agents, and policy engines; the legal license
text remains controlling.

See `LICENSE`, `LICENSES/`, and `KIYOSHIMA.json`.
